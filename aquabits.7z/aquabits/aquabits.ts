class Settings {
    static readonly blockSize:number = 32;
}

class XY {
    readonly x:number;
    readonly y:number;
    constructor(x:number, y:number) {
        this.x = x;
        this.y = y;
    }
}

abstract class SpriteComponent {
    protected img:HTMLImageElement;
    protected offsets:Array<XY>;
    scene:Scene;
    constructor(imgId:string) {
        this.img = <HTMLImageElement>document.getElementById(imgId);
        this.offsets = new Array<XY>();
        for(var y:number = 0; y < this.img.height; y += Settings.blockSize) {
            for(var x:number = 0; x < this.img.width; x += Settings.blockSize) {
                this.offsets.push(new XY(x, y));
            }
        }
    }
    abstract draw():void;
}

class Platform extends SpriteComponent {
    private readonly map:Array<Array<number>>;
    
    constructor(imgId:string, map:Array<Array<number>>) {
        super(imgId);
        this.offsets.splice(0, 0, null);
        this.map = map;
    }
    
    draw():void {
        for(var y:number = 0; y < this.map.length; y++) {
            for(var x:number = 0; x < this.map[y].length; x++) {
                var offset:XY = this.offsets[this.map[y][x]];
                if(offset != null) {
                    var pos:XY = new XY(x * Settings.blockSize, y * Settings.blockSize);
                    this.scene.drawBlock(this.img, offset, pos);
                }
            }
        }
    }
}

class Player extends SpriteComponent {
    position:XY;
    velocity:XY = new XY(0, 0);
    speed:number = 3;
    friction:number = 0.8;
    gravity:number = 0.4;
    jumping:boolean = false;
    grounded:boolean = false;
    moveOffsets:MoveOffsets;
    
    private offset:XY;
    
    constructor(imgId:string, startingPosition:XY, moveOffsets:MoveOffsets) {
        super(imgId);
        this.moveOffsets = moveOffsets;
        this.offset = moveOffsets.stop;
        this.position = startingPosition;
    }
    
    draw():void {
        this.scene.drawBlock(this.img, this.offset, this.position);
    }
}

class MoveOffsets {
    readonly stop:XY;
    readonly left:XY;
    readonly right:XY;
    
    constructor(stop:XY, right:XY, left:XY) {
        this.stop = stop;
        this.right = right;
        this.left = left;
    }
}

class Enemy extends SpriteComponent {
    position:XY;
    velocity:XY;
    minPosition:XY;
    maxPosition:XY;
    moveOffsets:MoveOffsets;
    
    private offset:XY;
    
    constructor(imgId:string, startingPosition:XY, moveOffsets:MoveOffsets) {
        super(imgId);
        this.moveOffsets = moveOffsets;
        this.offset = moveOffsets.stop;
        this.position = startingPosition;
    }
    
    draw():void {
        this.scene.drawBlock(this.img, this.offset, this.position);
    }
}

class Coin extends SpriteComponent {
    position:XY;
    private offset:XY;
    
    constructor(imgId:string, position:XY, offsetIdx:number) {
        super(imgId);
        this.offset = this.offsets[offsetIdx];
        this.position = position;
    }
    
    draw():void {
        this.scene.drawBlock(this.img, this.offset, this.position);
    }
}

class Scene {
    private readonly fill:CanvasPattern|CanvasGradient|string;
    private player:Player;
    private platform:Platform;
    private enemies:Array<Enemy>;
    private coins:Array<Coin>;

    readonly context:CanvasRenderingContext2D;
    readonly width:number;
    readonly height:number;
    
    constructor(context:CanvasRenderingContext2D, platform:Platform, player:Player, fill?:CanvasPattern|CanvasGradient|string) {
        this.context = context;
        this.width = context.canvas.width;
        this.height = context.canvas.height;

        platform.scene = this;
        this.platform = platform;

        player.scene = this;
        this.player = player;
        
        this.enemies = new Array<Enemy>();
        this.coins = new Array<Coin>();
        
        this.fill = fill;
    }
    
    addEnemy(enemy:Enemy):void {
        enemy.scene = this;
        this.enemies.push(enemy);
    }
    
    addCoin(coin:Coin):void {
        coin.scene = this;
        this.coins.push(coin);
    }
    
    draw():void {
        this.context.clearRect(0, 0, this.width, this.height);
        this.context.fillStyle = this.fill || "#000000";
        this.context.fillRect(0, 0, this.width, this.height);

        if(this.platform != null) {
            this.platform.draw();
        }

        if(this.player != null) {
            this.player.draw();
        }
        
        for(var enemy of this.enemies) {
            enemy.draw();
        }
        
        for(var coin of this.coins) {
            coin.draw();
        }
    }
    
    drawBlock(img:HTMLImageElement, offset:XY, position:XY):void {
        console.log(img);
        console.log(offset);
        console.log(position);
        this.context.drawImage(img, offset.x, offset.y, Settings.blockSize, Settings.blockSize, position.x, position.y, Settings.blockSize, Settings.blockSize);
    }
}