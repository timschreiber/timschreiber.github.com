var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Settings = /** @class */ (function () {
    function Settings() {
    }
    Settings.blockSize = 32;
    return Settings;
}());
var XY = /** @class */ (function () {
    function XY(x, y) {
        this.x = x;
        this.y = y;
    }
    return XY;
}());
var SpriteComponent = /** @class */ (function () {
    function SpriteComponent(imgId) {
        this.img = document.getElementById(imgId);
        this.offsets = new Array();
        for (var y = 0; y < this.img.height; y += Settings.blockSize) {
            for (var x = 0; x < this.img.width; x += Settings.blockSize) {
                this.offsets.push(new XY(x, y));
            }
        }
    }
    return SpriteComponent;
}());
var Platform = /** @class */ (function (_super) {
    __extends(Platform, _super);
    function Platform(imgId, map) {
        var _this = _super.call(this, imgId) || this;
        _this.offsets.splice(0, 0, null);
        _this.map = map;
        return _this;
    }
    Platform.prototype.draw = function () {
        for (var y = 0; y < this.map.length; y++) {
            for (var x = 0; x < this.map[y].length; x++) {
                var offset = this.offsets[this.map[y][x]];
                if (offset != null) {
                    var pos = new XY(x * Settings.blockSize, y * Settings.blockSize);
                    this.scene.drawBlock(this.img, offset, pos);
                }
            }
        }
    };
    return Platform;
}(SpriteComponent));
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player(imgId, startingPosition, moveOffsets) {
        var _this = _super.call(this, imgId) || this;
        _this.velocity = new XY(0, 0);
        _this.speed = 3;
        _this.friction = 0.8;
        _this.gravity = 0.4;
        _this.jumping = false;
        _this.grounded = false;
        _this.moveOffsets = moveOffsets;
        _this.offset = moveOffsets.stop;
        _this.position = startingPosition;
        return _this;
    }
    Player.prototype.draw = function () {
        this.scene.drawBlock(this.img, this.offset, this.position);
    };
    return Player;
}(SpriteComponent));
var MoveOffsets = /** @class */ (function () {
    function MoveOffsets(stop, right, left) {
        this.stop = stop;
        this.right = right;
        this.left = left;
    }
    return MoveOffsets;
}());
var Enemy = /** @class */ (function (_super) {
    __extends(Enemy, _super);
    function Enemy(imgId, startingPosition, moveOffsets) {
        var _this = _super.call(this, imgId) || this;
        _this.moveOffsets = moveOffsets;
        _this.offset = moveOffsets.stop;
        _this.position = startingPosition;
        return _this;
    }
    Enemy.prototype.draw = function () {
        this.scene.drawBlock(this.img, this.offset, this.position);
    };
    return Enemy;
}(SpriteComponent));
var Coin = /** @class */ (function (_super) {
    __extends(Coin, _super);
    function Coin(imgId, position, offsetIdx) {
        var _this = _super.call(this, imgId) || this;
        _this.offset = _this.offsets[offsetIdx];
        _this.position = position;
        return _this;
    }
    Coin.prototype.draw = function () {
        this.scene.drawBlock(this.img, this.offset, this.position);
    };
    return Coin;
}(SpriteComponent));
var Scene = /** @class */ (function () {
    function Scene(context, platform, player, fill) {
        this.context = context;
        this.width = context.canvas.width;
        this.height = context.canvas.height;
        platform.scene = this;
        this.platform = platform;
        player.scene = this;
        this.player = player;
        this.enemies = new Array();
        this.coins = new Array();
        this.fill = fill;
    }
    Scene.prototype.addEnemy = function (enemy) {
        enemy.scene = this;
        this.enemies.push(enemy);
    };
    Scene.prototype.addCoin = function (coin) {
        coin.scene = this;
        this.coins.push(coin);
    };
    Scene.prototype.draw = function () {
        this.context.clearRect(0, 0, this.width, this.height);
        this.context.fillStyle = this.fill || "#000000";
        this.context.fillRect(0, 0, this.width, this.height);
        if (this.platform != null) {
            this.platform.draw();
        }
        if (this.player != null) {
            this.player.draw();
        }
        for (var _i = 0, _a = this.enemies; _i < _a.length; _i++) {
            var enemy = _a[_i];
            enemy.draw();
        }
        for (var _b = 0, _c = this.coins; _b < _c.length; _b++) {
            var coin = _c[_b];
            coin.draw();
        }
    };
    Scene.prototype.drawBlock = function (img, offset, position) {
        console.log(img);
        console.log(offset);
        console.log(position);
        this.context.drawImage(img, offset.x, offset.y, Settings.blockSize, Settings.blockSize, position.x, position.y, Settings.blockSize, Settings.blockSize);
    };
    return Scene;
}());
